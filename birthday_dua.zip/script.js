
function createBalloonsAndRoses() {
    const balloonColors = ['red', 'blue', 'green', 'yellow', 'purple'];
    for (let i = 0; i < 20; i++) {
        let balloon = document.createElement('div');
        balloon.classList.add('balloon');
        balloon.style.left = Math.random() * 100 + 'vw';
        balloon.style.backgroundColor = balloonColors[Math.floor(Math.random() * balloonColors.length)];
        balloon.style.width = '20px';
        balloon.style.height = '30px';
        balloon.style.borderRadius = '50%';
        balloon.style.animationDuration = (3 + Math.random() * 5) + 's';
        document.querySelector('.balloons').appendChild(balloon);
    }

    for (let i = 0; i < 10; i++) {
        let rose = document.createElement('div');
        rose.classList.add('rose');
        rose.style.left = Math.random() * 100 + 'vw';
        rose.style.backgroundImage = 'url(https://upload.wikimedia.org/wikipedia/commons/4/42/Rose_icon.svg)';
        rose.style.backgroundSize = 'contain';
        rose.style.backgroundRepeat = 'no-repeat';
        rose.style.width = '30px';
        rose.style.height = '30px';
        rose.style.animationDuration = (3 + Math.random() * 5) + 's';
        document.querySelector('.roses').appendChild(rose);
    }
}
createBalloonsAndRoses();
